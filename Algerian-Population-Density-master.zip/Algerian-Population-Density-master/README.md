# Algerian-Population-Density
Algerian population density per wilaya (2008 wikipedia data) [Demo](https://dz-density.glitch.me/)

\ ゜ o ゜)ノ
